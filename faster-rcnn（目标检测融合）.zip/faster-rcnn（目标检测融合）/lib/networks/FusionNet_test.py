import tensorflow as tf
from .network import Network
from ..fast_rcnn.config import cfg
import numpy as np

class FusionNet_test(Network):
    def __init__(self, trainable=True):
        self.inputs = []
        self.datargb = tf.placeholder(tf.float32, shape=[None, None, None, 3])
        self.datad = tf.placeholder(tf.float32, shape=[None, None, None, 1])
        self.im_info = tf.placeholder(tf.float32, shape=[None, 3])
        self.keep_prob = tf.placeholder(tf.float32)
        self.layers = dict({'datargb':self.datargb, 'datad':self.datad, 'im_info': self.im_info})
        self.trainable = trainable
        self.setup()

    def setup(self):
        # n_classes = 21
        n_classes = cfg.NCLASSES
        # anchor_scales = [8, 16, 32]
        anchor_scales = cfg.ANCHOR_SCALES
        _feat_stride = [16, ]

        (self.feed('datargb').conv_SAE(name='conv_SAE',weight=np.load('../w.npy'))
         .max_pool(3, 3, 2, 2, padding='SAME', name='pooling1_SAE')
         .lrn(4, 0.001/9.0 ,0.75 ,name='norm_SAE')
         .conv(3, 3, 256, 1, 1, name='conv1')
         .conv(3, 3, 512, 1, 1, name='conv2')
         .conv(3, 3, 1024, 1, 1, name='conv3')
         .max_pool(3, 3, 2, 2, padding='SAME', name='pooling1')
         .lrn(4, 0.001/9.0 ,0.75 ,name='norm1'))

        (self.feed('datad')
         .conv_SAE(name='conv_SAE_d',weight=np.load('../w_d.npy'))
         .max_pool(3, 3, 2, 2, padding='SAME', name='pooling1_SAE_d')
         .lrn(4, 0.001/9.0 ,0.75 ,name='norm_SAE_d')
         .conv(3, 3, 1024, 1, 1, name='conv1_d')
         .max_pool(3, 3, 2, 2, padding='SAME', name='pooling1_d')
         .lrn(4, 0.001/9.0 ,0.75 ,name='norm1_d'))
        #
        # # (self.feed(self.feed('pool3').conv(3, 3, 256, 1, 1,relu=False,name='f1').get_output('f1')+
        # #    self.feed('pool3_d').conv(3, 3, 256, 1, 1,relu=False,name='f2').get_output('f2')).relu(name='fusion'))
        #
        (self.feed(self.feed('norm1').mul(name='f1').get_output('f1')+
                   self.feed('norm1_d').mul(name='f2').get_output('f2')).relu(name='fusion'))



        (self.feed('fusion')
         .conv(3, 3, 1024, 1, 1, name='rpn_conv/3x3')
         .conv(1, 1, len(anchor_scales) * 3 * 2, 1, 1, padding='VALID', relu=False, name='rpn_cls_score'))

        (self.feed('rpn_conv/3x3')
         .conv(1, 1, len(anchor_scales) * 3 * 4, 1, 1, padding='VALID', relu=False, name='rpn_bbox_pred'))

    #  shape is (1, H, W, Ax2) -> (1, H, WxA, 2)
        (self.feed('rpn_cls_score')
         .spatial_reshape_layer(2, name='rpn_cls_score_reshape')
         .spatial_softmax(name='rpn_cls_prob'))

    # shape is (1, H, WxA, 2) -> (1, H, W, Ax2)
        (self.feed('rpn_cls_prob')
         .spatial_reshape_layer(len(anchor_scales) * 3 * 2, name='rpn_cls_prob_reshape'))

        (self.feed('rpn_cls_prob_reshape', 'rpn_bbox_pred', 'im_info')
         .proposal_layer(_feat_stride, anchor_scales, 'TEST', name='rois'))

        (self.feed('fusion', 'rois')
         .roi_pool(7, 7, 1.0 / 16, name='pool_fusion')
         .fc(n_classes, relu=False, name='cls_score')
         .softmax(name='cls_prob'))

        (self.feed('pool_fusion')
         .fc(n_classes * 4, relu=False, name='bbox_pred'))